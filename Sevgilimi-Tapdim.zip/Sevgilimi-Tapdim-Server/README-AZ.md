# Sevgilimi Tapdım — onlayn server layihəsi (AZ)

Bu paket oyunun mövcud HTML funksiyalarını qoruyur və real onlayn imkanlar üçün backend başlanğıcı verir. **Server internetdə yerləşdirilməyib.** ABB ödənişi real merchant məlumatları olmadan aktiv deyil.

## Daxildir
- Təhlükəsiz şifrə heşi (bcrypt), JWT sessiyası, qeydiyyat və giriş API-si
- SQLite istifadəçi və ortaq mesaj bazası
- Serverdə creator/moderator rolları və creator üçün istifadəçi rol idarəetmə API-si
- Ümumi çat üçün API və WebSocket mesaj ötürülməsi
- Dostluq sorğuları və sorğuların qəbul/rədd API-si
- İstifadəçi şikayəti, moderator/yaradıcı üçün şikayət siyahısı və bağlama API-si
- WebRTC offer/answer/ICE siqnallarını yönləndirən `/rtc` WebSocket endpoint-i
- VIP/ABB status endpoint-i; real ödəniş qəsdən bağlı saxlanılıb
- PWA manifest və service worker

## Quraşdırma
1. Node.js 20+ quraşdır.
2. `.env.example` faylını `.env` kimi köçür.
3. `JWT_SECRET`-i ən azı 32 simvolluq unikal təsadüfi sirrlə dəyiş.
4. `CREATOR_EMAIL`-ə yaradıcının e-poçtunu yaz. `MODERATOR_EMAILS`-ə iki moderator e-poçtunu vergüllə ayıraraq yaz.
5. `npm install`
6. `npm start`
7. Brauzerdə `http://localhost:3000/Sevgilimi-Tapdim.html` aç.

## Təhlükəsizlik və məhdudiyyətlər
- Oyunun bütün əvvəlki bölmələri saxlanılır; yeni onlayn ekran əlavə olunub.
- Qeydiyyat və çat yalnız server işləyəndə real istifadəçilər arasında işləyir.
- WebRTC üçün zəng UI-si əlavə olunub, amma internet üzərindən etibarlı bağlantı üçün HTTPS və TURN serveri lazımdır; yalnız STUN bəzi şəbəkələrdə kifayət etməyə bilər.
- Creator hesabı `.env`-dəki e-poçta uyğun yaradılmalıdır. Moderasiya rollarını dəyişmək yalnız creator API-si ilə mümkündür.
- ABB üçün bankın rəsmi merchant hesabı, API sənədləri və callback/webhook yoxlaması tələb olunur; bu məlumatlar olmadan real ödəniş yaratmırıq.
- İstehsal istifadəsindən əvvəl HTTPS, e-poçt təsdiqi, parol bərpası, backup, jurnal/monitorinq, spam və şikayət alətləri, məxfilik siyasəti və təhlükəsizlik auditi lazımdır.
- İstifadəçi parolu heç vaxt brauzer yaddaşında saxlanmır; server bcrypt heşi saxlayır.
